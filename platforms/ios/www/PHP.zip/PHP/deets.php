<?php
$servername = "fdb12.biz.nf";
$username = "1756162_deets";
$password = "Bank@123";
$dbname = "1756162_deets";
?>